﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Score : MonoBehaviour
{
    public Text scoreText;
    private int score;
    public GameObject Gameover;
    public GameObject fallenEgg;
    public GameObject BaketntMove;
   
    
    void Update()
    {
        scoreText.text = score.ToString();
    }
    void OnTriggerEnter2D(Collider2D target)
    {
        if (target.tag == "bomb")
        {
           SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
           // Gameover.SetActive(true);
           // fallenEgg.SetActive(false);
            
        }
            
    }

    void OnTriggerExit2D(Collider2D target)
    {
        if (target.tag == "egg")
        {
            Destroy(target.gameObject);
            score++;
        }
    }
    
}
