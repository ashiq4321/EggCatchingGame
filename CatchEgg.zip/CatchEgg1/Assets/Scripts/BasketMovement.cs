﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasketMovement : MonoBehaviour
{
    private Rigidbody2D basketBody;
    public float speed, xbound;
    

    void Start()
    {
        basketBody = GetComponent<Rigidbody2D>();
    }


    void FixedUpdate()
    {
        float h = Input.GetAxis("Horizontal");

        if (h > 0)

            basketBody.velocity = Vector3.right * speed;

        else if (h < 0)

            basketBody.velocity = Vector3.left * speed;

        else
            basketBody.velocity = Vector3.zero;

        transform.position = new Vector3(Mathf.Clamp(transform.position.x, -xbound, xbound), transform.position.y);
    }

    
}
