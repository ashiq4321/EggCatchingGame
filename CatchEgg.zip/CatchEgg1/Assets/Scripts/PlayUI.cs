﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayUI : MonoBehaviour
{
    private GameManager Gmanager;
    void Awake()
    {
        SceneManager.LoadScene(0, LoadSceneMode.Additive);
    }
    void Start()
    {
        Gmanager = FindObjectOfType<GameManager>();
        
    }

    // Update is called once per frame
    void Update()
    {
        Time.timeScale = 0f;

    }
    public void Play()
    {
        SceneManager.LoadScene(0);
        Time.timeScale = 1f;
    }
}
