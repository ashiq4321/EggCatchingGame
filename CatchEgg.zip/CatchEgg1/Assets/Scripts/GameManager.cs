﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject GameOver;
    public GameObject fallenEgg;
    
    
    
    void Start()
    {
        Time.timeScale = 1f;
    }

    // Update is called once per frame
    void Update()
    {
        
        
    }
    public void Restart(Collider2D target)
    {
       // SceneManager.LoadScene(0);
       // SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

}
