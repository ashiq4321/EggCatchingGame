﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FallenObject : MonoBehaviour
{
    public GameObject[] eggs;
    public GameObject bomb;
    public float xbounds, ybound;
    
    void Start()
    {
        StartCoroutine(FallenRandomGameobject());
    }

    IEnumerator FallenRandomGameobject()
    {
        yield return new WaitForSeconds(Random.Range(1, 2));

        int randomEgg = Random.Range(0, eggs.Length);

        if (Random.value <= .6f)

            Instantiate(eggs[randomEgg], new Vector2(Random.Range(-xbounds, xbounds), ybound), Quaternion.identity);
        else
            Instantiate(bomb, new Vector2(Random.Range(-xbounds, xbounds), ybound), Quaternion.identity);


        StartCoroutine(FallenRandomGameobject());
    }

    
  
}
